import React from 'react';
import { Star, ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { motion } from 'motion/react';

interface ProductCardProps {
  key?: React.Key;
  product: Product;
  onSelect: (product: Product) => void;
}

export default function ProductCard({ product, onSelect }: ProductCardProps) {
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;
  const discountPercent = hasDiscount 
    ? Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)
    : 0;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3 }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-gray-100 bg-white transition-all hover:shadow-xl hover:shadow-gray-100/40"
    >
      {/* Product Image Panel */}
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        <img
          src={product.imageUrl}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-105"
        />
        
        {/* Discount Tag */}
        {hasDiscount && (
          <span className="absolute top-3 left-3 rounded-full bg-red-500 px-2.5 py-1 text-[11px] font-bold text-white uppercase tracking-wider">
            -{discountPercent}% OFF
          </span>
        )}

        {/* Category Badge */}
        <span className="absolute top-3 right-3 rounded-full bg-white/80 backdrop-blur-md px-2.5 py-1 text-[11px] font-medium text-gray-800 border border-gray-100">
          {product.category}
        </span>

        {/* Quick View Button Overlay */}
        <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-4">
          <button
            onClick={() => onSelect(product)}
            className="transform translate-y-2 group-hover:translate-y-0 transition-all bg-black text-white px-5 py-2.5 rounded-full font-medium text-xs tracking-wider flex items-center gap-1.5 shadow-lg shadow-black/25 hover:bg-neutral-800"
          >
            Ver Detalhes
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>
      </div>

      {/* Info Body */}
      <div className="flex flex-col flex-1 p-4">
        {/* Rating */}
        <div className="flex items-center gap-1 mb-1">
          <div className="flex text-yellow-400">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-3 w-3 ${
                  i < Math.floor(product.rating) ? 'fill-current' : 'text-gray-200'
                }`}
              />
            ))}
          </div>
          <span className="text-[10px] font-semibold text-gray-400">
            ({product.reviewsCount})
          </span>
        </div>

        {/* Product Title */}
        <h3 className="font-sans text-sm font-semibold text-gray-900 group-hover:text-black line-clamp-1 transition-colors">
          {product.name}
        </h3>
        
        {/* Description Snippet */}
        <p className="mt-1 font-sans text-xs text-gray-400 line-clamp-2 leading-relaxed">
          {product.description}
        </p>

        {/* Price & Action */}
        <div className="mt-auto pt-4 flex items-center justify-between">
          <div className="flex flex-col">
            {hasDiscount && (
              <span className="text-[11px] text-gray-400 line-through">
                R$ {product.originalPrice?.toFixed(2).replace('.', ',')}
              </span>
            )}
            <span className="text-sm font-bold text-gray-900">
              R$ {product.price.toFixed(2).replace('.', ',')}
            </span>
          </div>
          
          <button
            onClick={() => onSelect(product)}
            className="sm:hidden flex h-8 w-8 items-center justify-center rounded-full bg-black text-white hover:bg-neutral-800 transition-colors"
            title="Ver Detalhes"
          >
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
