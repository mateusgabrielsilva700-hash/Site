import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, Star, ShieldCheck, Truck, RefreshCw } from 'lucide-react';
import { Product } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (
    product: Product,
    quantity: number,
    size: string,
    color: { name: string; class: string }
  ) => void;
}

export default function ProductDetailModal({
  product,
  onClose,
  onAddToCart,
}: ProductDetailModalProps) {
  if (!product) return null;

  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<{ name: string; class: string } | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<boolean>(false);

  // Reset local state when product changes
  useEffect(() => {
    setSelectedSize(product.sizes[0] || '');
    setSelectedColor(product.colors[0] || null);
    setQuantity(1);
    setError('');
    setSuccess(false);
  }, [product]);

  const handleIncrement = () => setQuantity((prev) => prev + 1);
  const handleDecrement = () => setQuantity((prev) => (prev > 1 ? prev - 1 : 1));

  const handleAdd = () => {
    if (!selectedSize) {
      setError('Por favor, selecione um tamanho.');
      return;
    }
    if (!selectedColor) {
      setError('Por favor, selecione uma cor.');
      return;
    }
    setError('');
    onAddToCart(product, quantity, selectedSize, selectedColor);
    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      onClose();
    }, 1200);
  };

  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/40 backdrop-blur-sm"
        />

        {/* Modal Content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', duration: 0.4 }}
          className="relative w-full max-w-4xl overflow-hidden rounded-3xl bg-white shadow-2xl flex flex-col md:flex-row max-h-[90vh] md:max-h-none overflow-y-auto md:overflow-visible"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/90 shadow-md text-gray-500 hover:text-black hover:scale-105 transition-all border border-gray-100"
          >
            <X className="h-5 w-5" />
          </button>

          {/* Left Panel: Image */}
          <div className="w-full md:w-1/2 bg-gray-50 relative aspect-square md:aspect-auto md:h-full min-h-[300px] md:min-h-[500px]">
            <img
              src={product.imageUrl}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="absolute inset-0 h-full w-full object-cover object-center"
            />
            {hasDiscount && (
              <span className="absolute top-4 left-4 rounded-full bg-red-500 px-3 py-1.5 text-xs font-bold text-white uppercase tracking-wider shadow-md">
                Oferta Limitada
              </span>
            )}
          </div>

          {/* Right Panel: Controls */}
          <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[500px] md:max-h-[600px]">
            <div>
              {/* Product Category & Rating */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                  {product.category}
                </span>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-xs font-bold text-gray-700">
                    {product.rating.toFixed(1)}
                  </span>
                  <span className="text-[10px] text-gray-400">
                    ({product.reviewsCount} avaliações)
                  </span>
                </div>
              </div>

              {/* Title & Price */}
              <h2 className="font-sans text-xl sm:text-2xl font-black text-gray-900 tracking-tight">
                {product.name}
              </h2>
              
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-black text-black">
                  R$ {product.price.toFixed(2).replace('.', ',')}
                </span>
                {hasDiscount && (
                  <span className="text-sm text-gray-400 line-through">
                    R$ {product.originalPrice?.toFixed(2).replace('.', ',')}
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="mt-4 text-xs sm:text-sm text-gray-500 leading-relaxed">
                {product.description}
              </p>

              {/* Selector Divider */}
              <hr className="my-5 border-gray-100" />

              {/* Color Selector */}
              <div>
                <span className="text-xs font-bold text-gray-900 tracking-wide block mb-2.5">
                  COR: <span className="text-gray-500 font-medium">{selectedColor?.name}</span>
                </span>
                <div className="flex flex-wrap gap-2.5">
                  {product.colors.map((color) => (
                    <button
                      key={color.name}
                      onClick={() => setSelectedColor(color)}
                      className={`relative flex h-8 w-8 items-center justify-center rounded-full border-2 transition-all hover:scale-110 ${
                        selectedColor?.name === color.name ? 'border-black scale-105' : 'border-transparent'
                      }`}
                      title={color.name}
                    >
                      <span className={`h-6 w-6 rounded-full border border-gray-200/55 ${color.class}`} />
                      {selectedColor?.name === color.name && (
                        <span className="absolute -bottom-1 -right-1 flex h-3 w-3 items-center justify-center rounded-full bg-black">
                          <span className="h-1 w-1 rounded-full bg-white" />
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector */}
              <div className="mt-5">
                <span className="text-xs font-bold text-gray-900 tracking-wide block mb-2.5">
                  TAMANHO: <span className="text-gray-500 font-medium">{selectedSize}</span>
                </span>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`flex min-w-[40px] h-10 items-center justify-center rounded-lg border text-xs font-bold tracking-wider transition-all uppercase ${
                        selectedSize === size
                          ? 'border-black bg-black text-white shadow-sm'
                          : 'border-gray-200 text-gray-800 bg-white hover:border-black'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity Selector */}
              <div className="mt-5">
                <span className="text-xs font-bold text-gray-900 tracking-wide block mb-2.5">
                  QUANTIDADE
                </span>
                <div className="flex items-center w-32 justify-between border border-gray-200 rounded-lg p-1.5 bg-gray-50">
                  <button
                    onClick={handleDecrement}
                    className="flex h-7 w-7 items-center justify-center rounded-md hover:bg-white text-gray-600 active:scale-95 transition-all"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="text-sm font-bold text-gray-900 select-none">
                    {quantity}
                  </span>
                  <button
                    onClick={handleIncrement}
                    className="flex h-7 w-7 items-center justify-center rounded-md hover:bg-white text-gray-600 active:scale-95 transition-all"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Actions & Commit Banner */}
            <div className="mt-6 pt-4 border-t border-gray-100">
              {error && <p className="text-xs font-bold text-red-500 mb-2">{error}</p>}
              
              <button
                onClick={handleAdd}
                disabled={success}
                className={`w-full py-3.5 rounded-xl text-sm font-bold uppercase tracking-wider shadow-lg transition-all flex items-center justify-center gap-2 ${
                  success
                    ? 'bg-green-600 text-white shadow-green-100'
                    : 'bg-black hover:bg-neutral-800 text-white shadow-neutral-100 active:scale-[0.98]'
                }`}
              >
                {success ? 'Adicionado com Sucesso!' : 'Adicionar ao Carrinho'}
              </button>

              {/* Guarantees Grid */}
              <div className="grid grid-cols-3 gap-2 mt-4 text-[10px] text-gray-400 font-medium">
                <div className="flex flex-col items-center text-center p-2 rounded-lg bg-gray-50/50">
                  <Truck className="h-3.5 w-3.5 mb-1 text-black" />
                  <span>Entrega Expressa</span>
                </div>
                <div className="flex flex-col items-center text-center p-2 rounded-lg bg-gray-50/50">
                  <ShieldCheck className="h-3.5 w-3.5 mb-1 text-black" />
                  <span>Compra Segura</span>
                </div>
                <div className="flex flex-col items-center text-center p-2 rounded-lg bg-gray-50/50">
                  <RefreshCw className="h-3.5 w-3.5 mb-1 text-black" />
                  <span>Troca Grátis</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
