import React from 'react';
import { ShoppingBag, Search, HelpCircle, Instagram } from 'lucide-react';
import { STORE_NAME, STORE_INSTAGRAM } from '../data';

interface HeaderProps {
  cartItemsCount: number;
  onOpenCart: () => void;
  searchTerm: string;
  onSearchChange: (val: string) => void;
}

export default function Header({
  cartItemsCount,
  onOpenCart,
  searchTerm,
  onSearchChange,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-gray-100 bg-white/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          
          {/* Logo */}
          <div className="flex items-center gap-2">
            <a href="/" className="group flex items-center gap-2">
              <span className="h-8 w-8 rounded-full bg-black flex items-center justify-center text-white font-serif font-bold text-lg leading-none transition-transform group-hover:scale-105">
                A
              </span>
              <span className="font-sans text-xl font-black tracking-widest text-black uppercase">
                {STORE_NAME}
              </span>
            </a>
          </div>

          {/* Search Bar */}
          <div className="hidden sm:flex max-w-md flex-1 items-center gap-2 rounded-full border border-gray-200 bg-gray-50 px-4 py-1.5 focus-within:border-black focus-within:bg-white focus-within:ring-1 focus-within:ring-black transition-all">
            <Search className="h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar roupas, acessórios..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-transparent text-sm text-gray-900 outline-none placeholder:text-gray-400"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center gap-4">
            {/* Instagram Shortcut */}
            <a
              href={`https://instagram.com/${STORE_INSTAGRAM.replace('@', '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-black transition-colors"
              title="Siga no Instagram"
            >
              <Instagram className="h-5 w-5" />
            </a>

            {/* Cart Button */}
            <button
              id="cart-button"
              onClick={onOpenCart}
              className="relative flex h-10 w-10 items-center justify-center rounded-full border border-gray-200 hover:border-black transition-colors bg-white text-black"
              aria-label="Ver sacola"
            >
              <ShoppingBag className="h-5 w-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-black text-[10px] font-bold text-white animate-bounce">
                  {cartItemsCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="flex sm:hidden pb-3 pt-1">
          <div className="flex w-full items-center gap-2 rounded-full border border-gray-200 bg-gray-50 px-4 py-2 focus-within:border-black focus-within:bg-white transition-all">
            <Search className="h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar roupas..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-transparent text-sm text-gray-900 outline-none placeholder:text-gray-400"
            />
          </div>
        </div>
      </div>
    </header>
  );
}
