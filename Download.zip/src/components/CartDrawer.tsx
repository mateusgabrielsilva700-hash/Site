import React, { useState } from 'react';
import { X, ShoppingBag, Plus, Minus, Trash2, ArrowLeft, Send, CheckCircle2, Ticket, CreditCard, Landmark, DollarSign } from 'lucide-react';
import { CartItem, Order } from '../types';
import { STORE_NAME, STORE_WHATSAPP } from '../data';
import { motion, AnimatePresence } from 'motion/react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (cartItemId: string, delta: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [couponCode, setCouponCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0); // fraction (e.g. 0.10 for 10%)
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');

  // Checkout form state
  const [form, setForm] = useState<Order>({
    name: '',
    phone: '',
    cep: '',
    address: '',
    number: '',
    complement: '',
    paymentMethod: 'pix',
  });
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof Order, string>>>({});

  if (!isOpen) return null;

  // Coupon application logic
  const handleApplyCoupon = () => {
    setCouponError('');
    setCouponSuccess('');
    const code = couponCode.trim().toUpperCase();
    if (!code) {
      setCouponError('Digite um cupom válido.');
      return;
    }

    if (code === 'BEMVINDO' || code === 'TESTE10') {
      setAppliedDiscount(0.10);
      setCouponSuccess('Cupom BEMVINDO aplicado! 10% de desconto.');
    } else if (code === 'AURA20') {
      setAppliedDiscount(0.20);
      setCouponSuccess('Cupom AURA20 aplicado! 20% de desconto.');
    } else {
      setCouponError('Cupom inválido ou expirado.');
    }
  };

  // Totals calculations
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = subtotal * appliedDiscount;
  
  // PIX has a custom 5% payment method discount!
  const pixDiscount = form.paymentMethod === 'pix' ? (subtotal - discountAmount) * 0.05 : 0;
  
  const total = Math.max(0, subtotal - discountAmount - pixDiscount);

  // Form validatior
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (formErrors[name as keyof Order]) {
      setFormErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const errors: Partial<Record<keyof Order, string>> = {};
    if (!form.name.trim()) errors.name = 'Nome é obrigatório.';
    if (!form.phone.trim()) errors.phone = 'Telefone/WhatsApp é obrigatório.';
    if (!form.cep.trim()) errors.cep = 'CEP é obrigatório.';
    if (!form.address.trim()) errors.address = 'Endereço é obrigatório.';
    if (!form.number.trim()) errors.number = 'Número é obrigatório.';

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // WhatsApp Send trigger
  const handleFinalizeOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    // Compile message
    let message = `*🛍️ NOVO PEDIDO - ${STORE_NAME}*\n\n`;
    message += `*Cliente:* ${form.name}\n`;
    message += `*Telefone:* ${form.phone}\n`;
    message += `*CEP:* ${form.cep}\n`;
    message += `*Endereço:* ${form.address}, Nº ${form.number}${form.complement ? ` - ${form.complement}` : ''}\n\n`;

    message += `*--- PRODUTOS ---\n*`;
    cartItems.forEach((item) => {
      const itemPrice = item.product.price * item.quantity;
      message += `• ${item.quantity}x ${item.product.name}\n`;
      message += `  Tamanho: ${item.selectedSize} | Cor: ${item.selectedColor.name}\n`;
      message += `  Preço: R$ ${itemPrice.toFixed(2).replace('.', ',')}\n\n`;
    });

    if (appliedDiscount > 0) {
      message += `*Desconto Cupom:* -R$ ${discountAmount.toFixed(2).replace('.', ',')} (${appliedDiscount * 100}%)\n`;
    }
    if (form.paymentMethod === 'pix') {
      message += `*Desconto PIX (5%):* -R$ ${pixDiscount.toFixed(2).replace('.', ',')}\n`;
    }

    message += `*Forma de Pagamento:* ${form.paymentMethod.toUpperCase()}\n`;
    message += `*TOTAL DO PEDIDO:* R$ ${total.toFixed(2).replace('.', ',')}\n\n`;
    message += `👉 Aguardo as instruções para efetuar o pagamento. Obrigado!`;

    // Encode URL
    const encodedText = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${STORE_WHATSAPP}?text=${encodedText}`;

    // Go to success screen, clear cart, then open WhatsApp
    setStep('success');
    
    // Open in a new tab if allowed, otherwise just proceed
    window.open(whatsappUrl, '_blank');
  };

  const handleRestart = () => {
    onClearCart();
    setStep('cart');
    setCouponCode('');
    setAppliedDiscount(0);
    setCouponSuccess('');
    setCouponError('');
    setForm({
      name: '',
      phone: '',
      cep: '',
      address: '',
      number: '',
      complement: '',
      paymentMethod: 'pix',
    });
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        />

        <div className="absolute inset-y-0 right-0 flex max-w-full pl-10">
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
            className="w-screen max-w-md bg-white shadow-2xl flex flex-col h-full"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-gray-100 px-6 py-5">
              <div className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5 text-black" />
                <span className="font-sans text-lg font-black text-black uppercase tracking-wider">
                  Sua Sacola
                </span>
                {cartItems.length > 0 && (
                  <span className="rounded-full bg-black px-2 py-0.5 text-xs font-bold text-white">
                    {cartItems.reduce((acc, i) => acc + i.quantity, 0)}
                  </span>
                )}
              </div>
              <button
                onClick={onClose}
                className="rounded-full p-2 text-gray-400 hover:bg-gray-100 hover:text-black transition-all"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-y-auto p-6">
              {step === 'cart' && (
                <>
                  {cartItems.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full py-12 text-center">
                      <div className="rounded-full bg-gray-50 p-6 mb-4">
                        <ShoppingBag className="h-12 w-12 text-gray-300" />
                      </div>
                      <h3 className="text-base font-bold text-gray-900">Sua sacola está vazia</h3>
                      <p className="mt-1 text-xs text-gray-400 max-w-xs">
                        Adicione peças exclusivas do catálogo para experimentar o provador virtual de testes.
                      </p>
                      <button
                        onClick={onClose}
                        className="mt-6 px-6 py-2.5 rounded-full bg-black text-white text-xs font-bold uppercase tracking-wider hover:bg-neutral-800 transition-colors"
                      >
                        Ver Catálogo
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {/* Cart Items List */}
                      <div className="divide-y divide-gray-100">
                        {cartItems.map((item) => (
                          <div key={item.id} className="flex py-4 gap-4 first:pt-0">
                            <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl bg-gray-50 border border-gray-100">
                              <img
                                src={item.product.imageUrl}
                                alt={item.product.name}
                                referrerPolicy="no-referrer"
                                className="h-full w-full object-cover object-center"
                              />
                            </div>

                            <div className="flex flex-1 flex-col justify-between">
                              <div>
                                <div className="flex justify-between">
                                  <h4 className="text-xs sm:text-sm font-bold text-gray-900 line-clamp-1">
                                    {item.product.name}
                                  </h4>
                                  <span className="text-xs font-bold text-gray-900 ml-2">
                                    R$ {(item.product.price * item.quantity).toFixed(2).replace('.', ',')}
                                  </span>
                                </div>
                                <div className="mt-1 flex flex-wrap gap-x-2 text-[11px] text-gray-400 font-medium">
                                  <span>Tam: {item.selectedSize}</span>
                                  <span>•</span>
                                  <div className="flex items-center gap-1">
                                    <span>Cor:</span>
                                    <span className={`inline-block h-2 w-2 rounded-full border border-gray-200 ${item.selectedColor.class}`} />
                                    <span>{item.selectedColor.name}</span>
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center justify-between mt-2">
                                {/* Quantity Toggles */}
                                <div className="flex items-center border border-gray-100 rounded-md bg-gray-50/50 p-1">
                                  <button
                                    onClick={() => onUpdateQuantity(item.id, -1)}
                                    className="flex h-5 w-5 items-center justify-center rounded hover:bg-white text-gray-500"
                                  >
                                    <Minus className="h-3 w-3" />
                                  </button>
                                  <span className="text-xs font-bold text-gray-800 px-2 min-w-[20px] text-center">
                                    {item.quantity}
                                  </span>
                                  <button
                                    onClick={() => onUpdateQuantity(item.id, 1)}
                                    className="flex h-5 w-5 items-center justify-center rounded hover:bg-white text-gray-500"
                                  >
                                    <Plus className="h-3 w-3" />
                                  </button>
                                </div>

                                {/* Delete button */}
                                <button
                                  onClick={() => onRemoveItem(item.id)}
                                  className="text-gray-400 hover:text-red-500 transition-colors p-1"
                                  title="Remover item"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Coupon Section */}
                      <div className="border-t border-gray-100 pt-5">
                        <div className="flex items-center gap-1.5 mb-2.5">
                          <Ticket className="h-4 w-4 text-black" />
                          <span className="text-xs font-bold text-gray-900 uppercase tracking-wide">
                            Cupom de Desconto
                          </span>
                        </div>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Ex: BEMVINDO (10% OFF)"
                            value={couponCode}
                            onChange={(e) => setCouponCode(e.target.value)}
                            className="flex-1 rounded-xl border border-gray-200 px-3.5 py-2 text-xs text-gray-900 outline-none focus:border-black uppercase placeholder:normal-case placeholder:text-gray-400"
                          />
                          <button
                            onClick={handleApplyCoupon}
                            className="bg-black hover:bg-neutral-800 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all"
                          >
                            Aplicar
                          </button>
                        </div>
                        {couponError && <p className="text-[10px] font-bold text-red-500 mt-1">{couponError}</p>}
                        {couponSuccess && <p className="text-[10px] font-bold text-green-600 mt-1">{couponSuccess}</p>}
                      </div>
                    </div>
                  )}
                </>
              )}

              {step === 'checkout' && (
                <form onSubmit={handleFinalizeOrder} className="space-y-5">
                  <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
                    <button
                      type="button"
                      onClick={() => setStep('cart')}
                      className="text-gray-400 hover:text-black transition-colors"
                    >
                      <ArrowLeft className="h-5 w-5" />
                    </button>
                    <span className="font-sans text-sm font-bold text-gray-900 uppercase tracking-wider">
                      Dados de Entrega & Pagamento
                    </span>
                  </div>

                  {/* Name field */}
                  <div>
                    <label className="block text-[11px] font-bold text-gray-700 uppercase tracking-wide mb-1">
                      Nome Completo *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleInputChange}
                      placeholder="Ex: Mateus Silva"
                      className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs text-gray-900 outline-none focus:border-black"
                    />
                    {formErrors.name && <p className="text-[10px] font-bold text-red-500 mt-1">{formErrors.name}</p>}
                  </div>

                  {/* Phone field */}
                  <div>
                    <label className="block text-[11px] font-bold text-gray-700 uppercase tracking-wide mb-1">
                      WhatsApp/Celular *
                    </label>
                    <input
                      type="text"
                      name="phone"
                      value={form.phone}
                      onChange={handleInputChange}
                      placeholder="Ex: (11) 99999-9999"
                      className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs text-gray-900 outline-none focus:border-black"
                    />
                    {formErrors.phone && <p className="text-[10px] font-bold text-red-500 mt-1">{formErrors.phone}</p>}
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    {/* CEP */}
                    <div className="col-span-1">
                      <label className="block text-[11px] font-bold text-gray-700 uppercase tracking-wide mb-1">
                        CEP *
                      </label>
                      <input
                        type="text"
                        name="cep"
                        value={form.cep}
                        onChange={handleInputChange}
                        placeholder="01234-567"
                        className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs text-gray-900 outline-none focus:border-black"
                      />
                      {formErrors.cep && <p className="text-[10px] font-bold text-red-500 mt-1">{formErrors.cep}</p>}
                    </div>
                    {/* Endereco */}
                    <div className="col-span-2">
                      <label className="block text-[11px] font-bold text-gray-700 uppercase tracking-wide mb-1">
                        Endereço/Rua *
                      </label>
                      <input
                        type="text"
                        name="address"
                        value={form.address}
                        onChange={handleInputChange}
                        placeholder="Ex: Av. Paulista"
                        className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs text-gray-900 outline-none focus:border-black"
                      />
                      {formErrors.address && <p className="text-[10px] font-bold text-red-500 mt-1">{formErrors.address}</p>}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {/* Numero */}
                    <div>
                      <label className="block text-[11px] font-bold text-gray-700 uppercase tracking-wide mb-1">
                        Número *
                      </label>
                      <input
                        type="text"
                        name="number"
                        value={form.number}
                        onChange={handleInputChange}
                        placeholder="Ex: 150"
                        className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs text-gray-900 outline-none focus:border-black"
                      />
                      {formErrors.number && <p className="text-[10px] font-bold text-red-500 mt-1">{formErrors.number}</p>}
                    </div>
                    {/* Complemento */}
                    <div>
                      <label className="block text-[11px] font-bold text-gray-700 uppercase tracking-wide mb-1">
                        Complemento
                      </label>
                      <input
                        type="text"
                        name="complement"
                        value={form.complement}
                        onChange={handleInputChange}
                        placeholder="Ex: Apto 42"
                        className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs text-gray-900 outline-none focus:border-black"
                      />
                    </div>
                  </div>

                  {/* Payment Method Selector */}
                  <div>
                    <label className="block text-[11px] font-bold text-gray-700 uppercase tracking-wide mb-2">
                      Forma de Pagamento
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {/* PIX Option */}
                      <button
                        type="button"
                        onClick={() => setForm((p) => ({ ...p, paymentMethod: 'pix' }))}
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                          form.paymentMethod === 'pix'
                            ? 'border-black bg-black text-white shadow-sm'
                            : 'border-gray-200 bg-white text-gray-700 hover:border-black'
                        }`}
                      >
                        <Landmark className="h-4 w-4 mb-1" />
                        <span className="text-[10px] font-bold">PIX (-5%)</span>
                      </button>

                      {/* Card Option */}
                      <button
                        type="button"
                        onClick={() => setForm((p) => ({ ...p, paymentMethod: 'card' }))}
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                          form.paymentMethod === 'card'
                            ? 'border-black bg-black text-white shadow-sm'
                            : 'border-gray-200 bg-white text-gray-700 hover:border-black'
                        }`}
                      >
                        <CreditCard className="h-4 w-4 mb-1" />
                        <span className="text-[10px] font-bold">Cartão</span>
                      </button>

                      {/* Cash Option */}
                      <button
                        type="button"
                        onClick={() => setForm((p) => ({ ...p, paymentMethod: 'cash' }))}
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                          form.paymentMethod === 'cash'
                            ? 'border-black bg-black text-white shadow-sm'
                            : 'border-gray-200 bg-white text-gray-700 hover:border-black'
                        }`}
                      >
                        <DollarSign className="h-4 w-4 mb-1" />
                        <span className="text-[10px] font-bold">Dinheiro</span>
                      </button>
                    </div>
                  </div>
                </form>
              )}

              {isOpen && step === 'success' && (
                <div className="flex flex-col items-center justify-center text-center py-8">
                  <div className="rounded-full bg-green-50 p-5 text-green-500 mb-5 animate-pulse">
                    <CheckCircle2 className="h-14 w-14" />
                  </div>
                  <h3 className="text-lg font-black text-gray-900">Pedido Enviado!</h3>
                  <p className="mt-2 text-xs text-gray-500 max-w-sm leading-relaxed">
                    Seu pedido foi formatado e enviado diretamente para o WhatsApp de atendimento da {STORE_NAME}.
                  </p>

                  {/* PIX Promo instruction card if PIX was selected */}
                  {form.paymentMethod === 'pix' && (
                    <div className="mt-5 p-4 rounded-2xl bg-gray-50 border border-gray-100 text-left w-full">
                      <span className="text-[9px] font-bold text-white bg-black px-2 py-0.5 rounded-full uppercase">
                        Mock PIX QR Code para Teste
                      </span>
                      <p className="mt-2 text-[11px] text-gray-500 leading-normal">
                        Para simular o pagamento do PIX com 5% de desconto de teste:
                      </p>
                      {/* Simulate simple fake key */}
                      <div className="mt-2 bg-white border border-gray-100 rounded-lg p-2.5 flex items-center justify-between">
                        <span className="font-mono text-[10px] text-gray-700 select-all">
                          chave-pix-teste@aurastudio.com
                        </span>
                        <span className="text-[9px] font-bold text-gray-400">Copiar</span>
                      </div>
                    </div>
                  )}

                  <div className="mt-6 border-t border-gray-100 pt-5 w-full text-left space-y-2">
                    <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wide">Resumo do Pedido</h4>
                    <div className="text-[11px] text-gray-500 space-y-1">
                      <div className="flex justify-between">
                        <span>Cliente:</span>
                        <span className="font-semibold text-gray-900">{form.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total Pago:</span>
                        <span className="font-semibold text-gray-900">R$ {total.toFixed(2).replace('.', ',')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Pagamento:</span>
                        <span className="font-semibold text-gray-900 uppercase">{form.paymentMethod}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleRestart}
                    className="mt-8 w-full py-3.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-bold uppercase tracking-wider transition-all"
                  >
                    Voltar ao Início
                  </button>
                </div>
              )}
            </div>

            {/* Footer Summary / Sticky CTA */}
            {step !== 'success' && cartItems.length > 0 && (
              <div className="border-t border-gray-100 bg-gray-50/70 p-6 space-y-4">
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-gray-500">
                    <span>Subtotal</span>
                    <span>R$ {subtotal.toFixed(2).replace('.', ',')}</span>
                  </div>
                  {appliedDiscount > 0 && (
                    <div className="flex justify-between text-green-600 font-medium">
                      <span>Desconto Cupom</span>
                      <span>-R$ {discountAmount.toFixed(2).replace('.', ',')}</span>
                    </div>
                  )}
                  {form.paymentMethod === 'pix' && step === 'checkout' && (
                    <div className="flex justify-between text-green-600 font-medium animate-pulse">
                      <span>Desconto PIX (5%)</span>
                      <span>-R$ {pixDiscount.toFixed(2).replace('.', ',')}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-gray-500">
                    <span>Frete de Envio</span>
                    <span className="text-green-600 font-semibold uppercase text-[10px]">Grátis</span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-gray-900 pt-2 border-t border-gray-100">
                    <span>Total Estimado</span>
                    <span>R$ {total.toFixed(2).replace('.', ',')}</span>
                  </div>
                </div>

                {step === 'cart' ? (
                  <button
                    onClick={() => setStep('checkout')}
                    className="w-full bg-black hover:bg-neutral-800 text-white py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider shadow-lg shadow-neutral-100 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                  >
                    Finalizar Compra
                  </button>
                ) : (
                  <button
                    onClick={handleFinalizeOrder}
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider shadow-lg shadow-green-100 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                  >
                    <Send className="h-4 w-4" />
                    Enviar Pedido via WhatsApp
                  </button>
                )}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </AnimatePresence>
  );
}
