import React, { useState, useEffect } from 'react';
import { ShoppingBag, Star, HelpCircle, ArrowRight, Instagram, Gift, Sparkles, Filter } from 'lucide-react';
import Header from './components/Header';
import ProductCard from './components/ProductCard';
import ProductDetailModal from './components/ProductDetailModal';
import CartDrawer from './components/CartDrawer';
import { PRODUCTS, STORE_NAME, STORE_INSTAGRAM } from './data';
import { CartItem, Product } from './types';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('Todos');
  const [searchTerm, setSearchTerm] = useState('');

  // Load cart from localStorage on init for better testing experience
  useEffect(() => {
    const savedCart = localStorage.getItem('aura_cart');
    if (savedCart) {
      try {
        setCartItems(JSON.parse(savedCart));
      } catch (e) {
        console.error('Erro ao ler carrinho do localStorage', e);
      }
    }
  }, []);

  // Sync cart to localStorage on change
  const saveCart = (items: CartItem[]) => {
    setCartItems(items);
    localStorage.setItem('aura_cart', JSON.stringify(items));
  };

  const handleAddToCart = (
    product: Product,
    quantity: number,
    size: string,
    color: { name: string; class: string }
  ) => {
    const itemUniqueId = `${product.id}-${size}-${color.name.replace(/\s+/g, '')}`;
    const existingIndex = cartItems.findIndex((item) => item.id === itemUniqueId);

    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += quantity;
      saveCart(updated);
    } else {
      const newItem: CartItem = {
        id: itemUniqueId,
        product,
        quantity,
        selectedSize: size,
        selectedColor: color,
      };
      saveCart([...cartItems, newItem]);
    }
  };

  const handleUpdateQuantity = (cartItemId: string, delta: number) => {
    const updated = cartItems
      .map((item) => {
        if (item.id === cartItemId) {
          const newQty = item.quantity + delta;
          return { ...item, quantity: Math.max(1, newQty) };
        }
        return item;
      })
      .filter((item) => item.quantity > 0);
    saveCart(updated);
  };

  const handleRemoveItem = (cartItemId: string) => {
    const updated = cartItems.filter((item) => item.id !== cartItemId);
    saveCart(updated);
  };

  const handleClearCart = () => {
    saveCart([]);
  };

  // Filter products by category and search term
  const filteredProducts = PRODUCTS.filter((prod) => {
    const matchesCategory = activeCategory === 'Todos' || prod.category === activeCategory;
    const matchesSearch =
      prod.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prod.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prod.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const categories = ['Todos', 'Camisetas', 'Moletons', 'Jaquetas', 'Calças'];

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-gray-900 font-sans antialiased pb-20">
      {/* Test Environment Notice Banner */}
      <div className="bg-black text-white px-4 py-2 text-center text-xs font-semibold tracking-wide flex items-center justify-center gap-2">
        <Sparkles className="h-3.5 w-3.5 text-yellow-300 animate-spin" />
        <span>AMBIENTE DE TESTES ATIVO: Adicione produtos, aplique cupom e simule o envio direto para o WhatsApp!</span>
      </div>

      {/* Primary Header */}
      <Header
        cartItemsCount={cartItems.reduce((acc, i) => acc + i.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
      />

      {/* Main Grid Wrapper */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-6 sm:pt-10">
        
        {/* Promotion Banner Card */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-800 to-black text-white p-6 sm:p-10 mb-10 shadow-xl shadow-gray-200/50">
          <div className="relative z-10 max-w-xl">
            <span className="inline-flex items-center gap-1 rounded-full bg-white/10 px-3 py-1 text-xs font-bold text-white/90 backdrop-blur-md mb-4 border border-white/5">
              <Gift className="h-3.5 w-3.5 text-yellow-300" />
              Coleção de Lançamento
            </span>
            <h1 className="font-sans text-3xl sm:text-5xl font-black tracking-tight leading-none text-white">
              Estilo Essencial, <br className="hidden sm:block" />Conforto Sem Igual.
            </h1>
            <p className="mt-4 text-xs sm:text-sm text-gray-300 leading-relaxed max-w-md">
              Peças básicas com modelagem impecável e matérias-primas nobres. Desenvolvidas com o melhor caimento para o seu dia a dia.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <div className="rounded-xl bg-white/5 border border-white/10 px-4 py-2.5 backdrop-blur-sm">
                <span className="block text-[10px] text-gray-400 font-bold uppercase tracking-wider">Cupom Especial</span>
                <span className="font-mono text-sm font-black text-white">BEMVINDO (10% OFF)</span>
              </div>
              <div className="rounded-xl bg-white/5 border border-white/10 px-4 py-2.5 backdrop-blur-sm">
                <span className="block text-[10px] text-gray-400 font-bold uppercase tracking-wider">Frete de Envio</span>
                <span className="text-sm font-bold text-green-400">GRÁTIS BRASIL</span>
              </div>
            </div>
          </div>
          <div className="absolute right-0 bottom-0 top-0 w-1/3 hidden md:flex items-center justify-center opacity-10">
            <ShoppingBag className="h-64 w-64 text-white" />
          </div>
        </section>

        {/* Filter & Categories Bar */}
        <section className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-gray-100 pb-4">
            
            {/* Category Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
              <Filter className="h-4 w-4 text-gray-400 mr-1 flex-shrink-0" />
              {categories.map((cat) => {
                const isActive = activeCategory === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`relative rounded-full px-5 py-2 text-xs font-bold transition-all whitespace-nowrap ${
                      isActive
                        ? 'bg-black text-white shadow-md shadow-black/10'
                        : 'bg-white text-gray-600 border border-gray-100 hover:border-black'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>

            {/* Results Counter */}
            <span className="text-xs text-gray-400 font-medium self-end sm:self-auto">
              Mostrando {filteredProducts.length} {filteredProducts.length === 1 ? 'peça' : 'peças'}
            </span>
          </div>
        </section>

        {/* Products Grid */}
        <section id="products-grid">
          {filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center bg-white rounded-3xl border border-gray-100">
              <ShoppingBag className="h-12 w-12 text-gray-300 mb-3" />
              <h3 className="text-sm font-bold text-gray-900">Nenhuma peça encontrada</h3>
              <p className="text-xs text-gray-400 mt-1 max-w-xs">
                Tente redefinir os filtros de busca ou escolher outra categoria do menu acima.
              </p>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setActiveCategory('Todos');
                }}
                className="mt-4 text-xs font-bold text-black underline"
              >
                Limpar filtros de teste
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map((prod) => (
                <ProductCard
                  key={prod.id}
                  product={prod}
                  onSelect={(p) => setSelectedProduct(p)}
                />
              ))}
            </div>
          )}
        </section>

        {/* Interactive Guide section for testing */}
        <section className="mt-16 p-6 rounded-3xl bg-white border border-gray-100 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
          <div className="space-y-1 max-w-2xl">
            <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-1.5">
              <span>🚀 Como funciona o teste da sua loja?</span>
            </h4>
            <p className="text-xs text-gray-500 leading-relaxed">
              Este é um MVP funcional do seu site de roupas. Quando um cliente navega pelo catálogo, escolhe o tamanho/cor e preenche os dados no carrinho, o site gera automaticamente o pedido formatado em uma mensagem pronta e direciona para o seu WhatsApp! Isso reduz os custos de taxas e automatiza seu atendimento.
            </p>
          </div>
          <div className="flex gap-3 flex-shrink-0">
            <button
              onClick={() => setIsCartOpen(true)}
              className="px-5 py-2.5 rounded-full bg-black text-white text-xs font-bold flex items-center gap-1.5 hover:bg-neutral-800 transition-all"
            >
              Abrir Sacola de Teste
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </section>

      </main>

      {/* Footer Branding */}
      <footer className="mt-20 border-t border-gray-100 bg-white py-10 text-center">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="h-6 w-6 rounded-full bg-black text-white font-serif font-bold text-sm flex items-center justify-center">
              A
            </span>
            <span className="font-sans text-sm font-black tracking-widest text-black uppercase">
              {STORE_NAME}
            </span>
          </div>
          <p className="text-[11px] text-gray-400">
            © 2026 {STORE_NAME}. Desenvolvido como modelo de testes e simulação comercial.
          </p>
          <a
            href={`https://instagram.com/${STORE_INSTAGRAM.replace('@', '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-gray-500 hover:text-black font-semibold flex items-center gap-1 mt-1 transition-colors"
          >
            <Instagram className="h-3.5 w-3.5" />
            {STORE_INSTAGRAM}
          </a>
        </div>
      </footer>

      {/* App Modals & Drawer Overlays */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />
    </div>
  );
}
