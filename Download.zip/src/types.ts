export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: 'Camisetas' | 'Moletons' | 'Jaquetas' | 'Calças';
  imageUrl: string;
  sizes: string[];
  colors: { name: string; class: string }[];
  inStock: boolean;
  rating: number;
  reviewsCount: number;
}

export interface CartItem {
  id: string; // unique combination of product id, size, and color
  product: Product;
  quantity: number;
  selectedSize: string;
  selectedColor: { name: string; class: string };
}

export interface Order {
  name: string;
  phone: string;
  cep: string;
  address: string;
  number: string;
  complement?: string;
  paymentMethod: 'pix' | 'card' | 'cash';
}
