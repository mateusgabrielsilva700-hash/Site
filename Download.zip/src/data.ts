import { Product } from './types';

export const STORE_NAME = 'AURA Studio';
export const STORE_WHATSAPP = '5511999999999'; // Example phone number for Brazil
export const STORE_INSTAGRAM = '@aurastudio.minimal';

export const PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Camiseta Minimalista Algodão',
    description: 'Camiseta premium confeccionada em algodão 100% orgânico com modelagem clássica. Toque extremamente macio, gola de ribana encorpada e costura reforçada para alta durabilidade. Perfeita para um look clean e atemporal.',
    price: 89.90,
    originalPrice: 119.90,
    category: 'Camisetas',
    imageUrl: '/src/assets/images/camiseta_minimalista_1784246891577.jpg',
    sizes: ['P', 'M', 'G', 'GG'],
    colors: [
      { name: 'Branco Off-White', class: 'bg-[#F4F1EA]' },
      { name: 'Preto Coal', class: 'bg-[#1C1C1C]' },
      { name: 'Verde Oliva', class: 'bg-[#4B5320]' }
    ],
    inStock: true,
    rating: 4.9,
    reviewsCount: 42
  },
  {
    id: 'prod-2',
    name: 'Moletom Oversized Confort',
    description: 'Moletom com capuz e corte oversized para máximo estilo e conforto. Interior peluciado ultra macio, punhos canelados largos e bolso canguru. O abrigo perfeito para dias frios com estilo streetwear minimalista.',
    price: 189.90,
    category: 'Moletons',
    imageUrl: '/src/assets/images/moletom_oversized_1784246901134.jpg',
    sizes: ['M', 'G', 'GG'],
    colors: [
      { name: 'Cinza Mescla', class: 'bg-[#3A3B3C]' },
      { name: 'Bege Areia', class: 'bg-[#D2B48C]' },
      { name: 'Preto Coal', class: 'bg-[#1C1C1C]' }
    ],
    inStock: true,
    rating: 4.8,
    reviewsCount: 28
  },
  {
    id: 'prod-3',
    name: 'Jaqueta Jeans Clássica',
    description: 'Jaqueta jeans com lavagem clássica e estruturada em denim de alta gramatura. Possui bolsos frontais com lapela, bolsos laterais embutidos e botões metálicos personalizados. Uma peça curinga para qualquer estação.',
    price: 249.90,
    originalPrice: 299.90,
    category: 'Jaquetas',
    imageUrl: '/src/assets/images/jaqueta_jeans_1784246910638.jpg',
    sizes: ['P', 'M', 'G'],
    colors: [
      { name: 'Azul Denim', class: 'bg-[#4682B4]' },
      { name: 'Jeans Escuro', class: 'bg-[#1C2E4A]' }
    ],
    inStock: true,
    rating: 5.0,
    reviewsCount: 15
  },
  {
    id: 'prod-4',
    name: 'Calça Cargo Casual',
    description: 'Calça cargo casual produzida em sarja de algodão de alta resistência. Modelagem levemente afunilada com punhos ajustáveis, bolsos laterais utilitários funcionais e cós elástico com cordão para ajuste perfeito.',
    price: 159.90,
    category: 'Calças',
    imageUrl: '/src/assets/images/calca_cargo_1784246919743.jpg',
    sizes: ['38', '40', '42', '44', '46'],
    colors: [
      { name: 'Bege Khaki', class: 'bg-[#C2B280]' },
      { name: 'Verde Militar', class: 'bg-[#355E3B]' },
      { name: 'Preto Coal', class: 'bg-[#1C1C1C]' }
    ],
    inStock: true,
    rating: 4.7,
    reviewsCount: 31
  }
];
